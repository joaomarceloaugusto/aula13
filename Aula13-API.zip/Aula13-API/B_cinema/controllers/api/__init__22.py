from .api_v1_controller import api_v1_bp
from flask import Blueprint
__all__ = dashboard_bp = Blueprint("dashboard", __name__)
